#!/bin/sh
java -classpath APJP_LOCAL_JAVA-1.0.1.jar APJP/Main